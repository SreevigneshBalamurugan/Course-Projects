module pc_mux (
    input  wire        rst_in,
    input  wire [1:0]  pc_src_in,
    input  wire [31:0] pc_in,
    input  wire [31:0] epc_in,
    input  wire [31:0] trap_address_in,
    input  wire        branch_taken_in,
    input  wire [31:0] iaddr_in,
    input  wire        ahb_ready_in,

    output reg  [31:0] iaddr_out,
    output wire [31:0] pc_plus_4_out,
    output reg  [31:0] pc_mux_out,
    output wire        misaligned_instr_logic_out
);

parameter BOOT_ADDRESS = 32'h00000000;

assign pc_plus_4_out = pc_in + 32'd4;

wire [31:0] next_pc;

assign next_pc =
        (pc_src_in == 2'b00) ? pc_plus_4_out :
        (pc_src_in == 2'b01) ? iaddr_in :
        (pc_src_in == 2'b10) ? trap_address_in :
                               epc_in;

assign misaligned_instr_logic_out =
        branch_taken_in & next_pc[1];

always @(*) begin
    pc_mux_out = next_pc;
end

always @(*) begin
    if (rst_in)
        iaddr_out = BOOT_ADDRESS;
    else if (ahb_ready_in)
        iaddr_out = pc_mux_out;
    else
        iaddr_out = pc_in;
end

endmodule
