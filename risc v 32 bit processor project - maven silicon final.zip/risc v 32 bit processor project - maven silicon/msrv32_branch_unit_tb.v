`timescale 1ns/1ps

module msrv32_branch_unit_tb;

reg [31:0] rs1_in;
reg [31:0] rs2_in;
reg [4:0] opcode_in;
reg [2:0] funct3_in;

wire branch_taken_out;

msrv32_branch_unit DUT(
    .rs1_in(rs1_in),
    .rs2_in(rs2_in),
    .opcode_in(opcode_in),
    .funct3_in(funct3_in),
    .branch_taken_out(branch_taken_out)
);

initial begin

    opcode_in = 5'b11000;

    // BEQ
    rs1_in = 10;
    rs2_in = 10;
    funct3_in = 3'b000;
    #10;

    // BNE
    rs1_in = 10;
    rs2_in = 20;
    funct3_in = 3'b001;
    #10;

    // BLT
    rs1_in = -5;
    rs2_in = 3;
    funct3_in = 3'b100;
    #10;

    // BGE
    rs1_in = 10;
    rs2_in = 5;
    funct3_in = 3'b101;
    #10;

    $finish;

end

endmodule
