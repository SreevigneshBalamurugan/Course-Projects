`timescale 1ns/1ps

module msrv32_instruction_mux_tb;

reg flush_in;
reg [31:0] ms_riscv32_mp_instr_in;

wire [6:0] opcode_out;
wire [2:0] funct3_out;
wire [6:0] funct7_out;
wire [4:0] rs1addr_out;
wire [4:0] rs2addr_out;
wire [4:0] rdaddr_out;
wire [11:0] csr_addr_out;
wire [24:0] instr_31_7_out;

msrv32_instruction_mux DUT(
    .flush_in(flush_in),
    .ms_riscv32_mp_instr_in(ms_riscv32_mp_instr_in),
    .opcode_out(opcode_out),
    .funct3_out(funct3_out),
    .funct7_out(funct7_out),
    .rs1addr_out(rs1addr_out),
    .rs2addr_out(rs2addr_out),
    .rdaddr_out(rdaddr_out),
    .csr_addr_out(csr_addr_out),
    .instr_31_7_out(instr_31_7_out)
);

initial begin

    flush_in = 0;

    // ADD x5,x6,x7
    ms_riscv32_mp_instr_in =
    32'b0000000_00111_00110_000_00101_0110011;

    #10;

    flush_in = 1;

    #10;

    $finish;

end

endmodule
