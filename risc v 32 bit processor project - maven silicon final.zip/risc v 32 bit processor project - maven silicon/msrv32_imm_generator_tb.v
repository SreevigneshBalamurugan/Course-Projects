`timescale 1ns/1ps

module msrv32_imm_generator_tb;

reg [24:0] instr_in;
reg [2:0] imm_type_in;

wire [31:0] imm_out;

msrv32_imm_generator DUT(
    .instr_in(instr_in),
    .imm_type_in(imm_type_in),
    .imm_out(imm_out)
);

initial begin

    // I-Type
    instr_in = 25'h123456;
    imm_type_in = 3'b000;
    #10;

    // S-Type
    imm_type_in = 3'b001;
    #10;

    // B-Type
    imm_type_in = 3'b010;
    #10;

    // U-Type
    imm_type_in = 3'b011;
    #10;

    // J-Type
    imm_type_in = 3'b100;
    #10;

    // CSR-Type
    imm_type_in = 3'b101;
    #10;

    $finish;

end

initial begin
    $monitor("Time=%0t imm_type=%b imm_out=%h",
              $time, imm_type_in, imm_out);
end

endmodule
