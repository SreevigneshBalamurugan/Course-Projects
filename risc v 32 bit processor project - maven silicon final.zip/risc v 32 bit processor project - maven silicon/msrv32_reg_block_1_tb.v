`timescale 1ns/1ps

module msrv32_reg_block_1_tb;

reg clk_in;
reg rst_in;
reg [31:0] pc_mux_in;

wire [31:0] pc_out;

msrv32_reg_block_1 DUT (
    .clk_in(clk_in),
    .rst_in(rst_in),
    .pc_mux_in(pc_mux_in),
    .pc_out(pc_out)
);

always #5 clk_in = ~clk_in;

initial begin

    clk_in = 0;
    rst_in = 1;
    pc_mux_in = 32'h00000000;

    // Reset active
    #10;

    rst_in = 0;

    // First value
    pc_mux_in = 32'h00001000;
    #10;

    // Second value
    pc_mux_in = 32'h00002000;
    #10;

    // Third value
    pc_mux_in = 32'h00003000;
    #10;

    // Apply reset again
    rst_in = 1;
    #10;

    rst_in = 0;
    pc_mux_in = 32'h00004000;
    #10;

    $finish;

end

initial begin
    $monitor("Time=%0t rst=%b pc_mux_in=%h pc_out=%h",
              $time, rst_in, pc_mux_in, pc_out);
end

endmodule
