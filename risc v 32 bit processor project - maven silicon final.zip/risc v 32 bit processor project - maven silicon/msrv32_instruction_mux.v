module msrv32_instruction_mux(

    input wire flush_in,
    input wire [31:0] ms_riscv32_mp_instr_in,

    output wire [6:0] opcode_out,
    output wire [2:0] funct3_out,
    output wire [6:0] funct7_out,

    output wire [4:0] rs1addr_out,
    output wire [4:0] rs2addr_out,
    output wire [4:0] rdaddr_out,

    output wire [11:0] csr_addr_out,
    output wire [24:0] instr_31_7_out
);

wire [31:0] instr;

assign instr =
        flush_in ?
        32'h00000013 :
        ms_riscv32_mp_instr_in;

assign opcode_out      = instr[6:0];
assign rdaddr_out      = instr[11:7];
assign funct3_out      = instr[14:12];
assign rs1addr_out     = instr[19:15];
assign rs2addr_out     = instr[24:20];
assign funct7_out      = instr[31:25];

assign csr_addr_out    = instr[31:20];
assign instr_31_7_out  = instr[31:7];

endmodule
