`timescale 1ns/1ps

module pc_mux_tb;

reg rst_in;
reg [1:0] pc_src_in;
reg [31:0] pc_in;
reg [31:0] epc_in;
reg [31:0] trap_address_in;
reg branch_taken_in;
reg [31:0] iaddr_in;
reg ahb_ready_in;

wire [31:0] iaddr_out;
wire [31:0] pc_plus_4_out;
wire [31:0] pc_mux_out;
wire misaligned_instr_logic_out;

pc_mux DUT (
    .rst_in(rst_in),
    .pc_src_in(pc_src_in),
    .pc_in(pc_in),
    .epc_in(epc_in),
    .trap_address_in(trap_address_in),
    .branch_taken_in(branch_taken_in),
    .iaddr_in(iaddr_in),
    .ahb_ready_in(ahb_ready_in),

    .iaddr_out(iaddr_out),
    .pc_plus_4_out(pc_plus_4_out),
    .pc_mux_out(pc_mux_out),
    .misaligned_instr_logic_out(misaligned_instr_logic_out)
);

initial begin

    rst_in = 1;
    pc_src_in = 0;
    pc_in = 32'h1000;
    epc_in = 32'h2000;
    trap_address_in = 32'h3000;
    iaddr_in = 32'h4000;
    branch_taken_in = 0;
    ahb_ready_in = 1;

    #10;

    // Reset check
    rst_in = 0;

    // Normal PC+4
    pc_src_in = 2'b00;
    #10;

    // Branch target
    pc_src_in = 2'b01;
    #10;

    // Trap address
    pc_src_in = 2'b10;
    #10;

    // EPC
    pc_src_in = 2'b11;
    #10;

    // Misaligned address test
    branch_taken_in = 1;
    iaddr_in = 32'h4002;
    pc_src_in = 2'b01;
    #10;

    $finish;
end

initial begin
    $monitor("time=%0t rst=%b pc_src=%b iaddr_out=%h pc_mux_out=%h misaligned=%b",
              $time,rst_in,pc_src_in,
              iaddr_out,pc_mux_out,
              misaligned_instr_logic_out);
end

endmodule
