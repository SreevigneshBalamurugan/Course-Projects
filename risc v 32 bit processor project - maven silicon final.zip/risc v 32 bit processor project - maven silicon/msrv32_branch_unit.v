module msrv32_branch_unit(

    input wire [31:0] rs1_in,
    input wire [31:0] rs2_in,

    input wire [4:0] opcode_in,
    input wire [2:0] funct3_in,

    output reg branch_taken_out
);

always @(*) begin

    branch_taken_out = 1'b0;

    if(opcode_in == 5'b11000)
    begin

        case(funct3_in)

            3'b000: branch_taken_out = (rs1_in == rs2_in); // BEQ

            3'b001: branch_taken_out = (rs1_in != rs2_in); // BNE

            3'b100:
                branch_taken_out =
                ($signed(rs1_in) < $signed(rs2_in)); // BLT

            3'b101:
                branch_taken_out =
                ($signed(rs1_in) >= $signed(rs2_in)); // BGE

            3'b110:
                branch_taken_out =
                (rs1_in < rs2_in); // BLTU

            3'b111:
                branch_taken_out =
                (rs1_in >= rs2_in); // BGEU

            default:
                branch_taken_out = 1'b0;

        endcase
    end
end

endmodule
