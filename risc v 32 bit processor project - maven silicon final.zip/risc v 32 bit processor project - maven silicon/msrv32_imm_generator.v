module msrv32_imm_generator (

    input wire [24:0] instr_in,
    input wire [2:0] imm_type_in,

    output reg [31:0] imm_out
);

wire [31:0] i_type;
wire [31:0] s_type;
wire [31:0] b_type;
wire [31:0] u_type;
wire [31:0] j_type;
wire [31:0] csr_type;

assign i_type =
{{20{instr_in[24]}}, instr_in[24:13]};

assign s_type =
{{20{instr_in[24]}}, instr_in[24:18], instr_in[4:0]};

assign b_type =
{{20{instr_in[24]}},
instr_in[0],
instr_in[23:18],
instr_in[4:1],
1'b0};

assign u_type =
{instr_in[24:5],12'b0};

assign j_type =
{{12{instr_in[24]}},
instr_in[12:5],
instr_in[13],
instr_in[23:14],
1'b0};

assign csr_type =
{27'b0,instr_in[19:15]};

always @(*)
begin
    case(imm_type_in)

        3'b000: imm_out = i_type;
        3'b001: imm_out = s_type;
        3'b010: imm_out = b_type;
        3'b011: imm_out = u_type;
        3'b100: imm_out = j_type;
        3'b101: imm_out = csr_type;

        default:
            imm_out = 32'b0;
    endcase
end

endmodule
