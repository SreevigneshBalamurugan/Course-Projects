`timescale 1ns/1ps

module msrv32_integer_file_tb;

reg clk;
reg rst;

reg [4:0] rs_1_addr_in;
reg [4:0] rs_2_addr_in;
reg [4:0] rd_addr_in;

reg wr_en_in;
reg [31:0] rd_in;

wire [31:0] rs_1_out;
wire [31:0] rs_2_out;

msrv32_integer_file DUT (
    .ms_riscv32_mp_clk_in(clk),
    .ms_riscv32_mp_rst_in(rst),

    .rs_1_addr_in(rs_1_addr_in),
    .rs_2_addr_in(rs_2_addr_in),
    .rd_addr_in(rd_addr_in),

    .wr_en_in(wr_en_in),
    .rd_in(rd_in),

    .rs_1_out(rs_1_out),
    .rs_2_out(rs_2_out)
);

always #5 clk = ~clk;

initial begin

    clk = 0;
    rst = 1;

    wr_en_in = 0;
    rs_1_addr_in = 0;
    rs_2_addr_in = 0;
    rd_addr_in = 0;
    rd_in = 0;

    #10;
    rst = 0;

    // write x5 = 100
    rd_addr_in = 5;
    rd_in = 32'd100;
    wr_en_in = 1;

    #10;

    // read x5
    wr_en_in = 0;
    rs_1_addr_in = 5;

    #10;

    // write x10 = 500
    rd_addr_in = 10;
    rd_in = 32'd500;
    wr_en_in = 1;

    #10;

    // read x5 and x10
    wr_en_in = 0;
    rs_1_addr_in = 5;
    rs_2_addr_in = 10;

    #20;

    $finish;

end

endmodule
