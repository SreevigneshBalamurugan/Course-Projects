`timescale 1ns/1ps

module msrv32_immediate_adder_tb;

reg [31:0] pc_in;
reg [31:0] rs_1_in;
reg [31:0] imm_in;
reg iadder_src_in;

wire [31:0] iadder_out;

msrv32_immediate_adder DUT(
    .pc_in(pc_in),
    .rs_1_in(rs_1_in),
    .imm_in(imm_in),
    .iadder_src_in(iadder_src_in),
    .iadder_out(iadder_out)
);

initial begin

    // PC + IMM
    pc_in = 32'd100;
    rs_1_in = 32'd50;
    imm_in = 32'd20;
    iadder_src_in = 0;

    #10;

    // RS1 + IMM
    iadder_src_in = 1;

    #10;

    // Another example
    rs_1_in = 32'd500;
    imm_in = 32'd100;

    #10;

    $finish;

end

initial begin
    $monitor("Time=%0t src=%b pc=%d rs1=%d imm=%d out=%d",
             $time,
             iadder_src_in,
             pc_in,
             rs_1_in,
             imm_in,
             iadder_out);
end

endmodule
