`timescale 1ns/1ps

module msrv32_wr_en_generator_tb;

reg flush_in;
reg rf_wr_en_reg_in;
reg csr_wr_en_reg_in;

wire wr_en_int_file_out;
wire wr_en_csr_file_out;

msrv32_wr_en_generator DUT(
    .flush_in(flush_in),
    .rf_wr_en_reg_in(rf_wr_en_reg_in),
    .csr_wr_en_reg_in(csr_wr_en_reg_in),
    .wr_en_int_file_out(wr_en_int_file_out),
    .wr_en_csr_file_out(wr_en_csr_file_out)
);

initial begin

    flush_in = 0;
    rf_wr_en_reg_in = 1;
    csr_wr_en_reg_in = 1;

    #10;

    flush_in = 1;

    #10;

    flush_in = 0;
    rf_wr_en_reg_in = 1;
    csr_wr_en_reg_in = 0;

    #10;

    $finish;
end

endmodule
