module msrv32_integer_file (

    input  wire        ms_riscv32_mp_clk_in,
    input  wire        ms_riscv32_mp_rst_in,

    input  wire [4:0]  rs_1_addr_in,
    input  wire [4:0]  rs_2_addr_in,
    input  wire [4:0]  rd_addr_in,

    input  wire        wr_en_in,
    input  wire [31:0] rd_in,

    output wire [31:0] rs_1_out,
    output wire [31:0] rs_2_out
);

reg [31:0] reg_file [31:0];

integer i;

always @(posedge ms_riscv32_mp_clk_in or posedge ms_riscv32_mp_rst_in)
begin
    if(ms_riscv32_mp_rst_in)
    begin
        for(i=0; i<32; i=i+1)
            reg_file[i] <= 32'b0;
    end
    else if(wr_en_in && (rd_addr_in != 5'd0))
    begin
        reg_file[rd_addr_in] <= rd_in;
    end
end

assign rs_1_out =
        (rs_1_addr_in == 5'd0) ?
        32'b0 :
        reg_file[rs_1_addr_in];

assign rs_2_out =
        (rs_2_addr_in == 5'd0) ?
        32'b0 :
        reg_file[rs_2_addr_in];

endmodule
