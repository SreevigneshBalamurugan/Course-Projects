`timescale 1ns/1ps

module msrv32_alu_tb;

reg [31:0] op_1_in;
reg [31:0] op_2_in;
reg [3:0] opcode_in;

wire [31:0] result_out;

msrv32_alu DUT(
    .op_1_in(op_1_in),
    .op_2_in(op_2_in),
    .opcode_in(opcode_in),
    .result_out(result_out)
);

initial begin

    op_1_in = 20;
    op_2_in = 10;

    opcode_in = 4'b0000; #10; // ADD
    opcode_in = 4'b0001; #10; // SUB
    opcode_in = 4'b0010; #10; // AND
    opcode_in = 4'b0011; #10; // OR
    opcode_in = 4'b0100; #10; // XOR
    opcode_in = 4'b0101; #10; // SLL
    opcode_in = 4'b0110; #10; // SRL
    opcode_in = 4'b1000; #10; // SLT

    $finish;

end

endmodule
