`timescale 1ns/1ps

module msrv32_store_unit_tb;

reg [2:0]  funct3_in;
reg [31:0] iadder_in;
reg [31:0] rs2_in;
reg        mem_wr_req_in;
reg        ahb_ready_in;

wire [31:0] ms_riscv32_mp_dmdata_out;
wire [31:0] ms_riscv32_mp_dmaddr_out;
wire [3:0]  ms_riscv32_mp_dmwr_mask_out;
wire        ms_riscv32_mp_dmwr_req_out;
wire [1:0]  ahb_htrans_out;

msrv32_store_unit DUT(

    .funct3_in(funct3_in),
    .iadder_in(iadder_in),
    .rs2_in(rs2_in),
    .mem_wr_req_in(mem_wr_req_in),
    .ahb_ready_in(ahb_ready_in),

    .ms_riscv32_mp_dmdata_out(ms_riscv32_mp_dmdata_out),
    .ms_riscv32_mp_dmaddr_out(ms_riscv32_mp_dmaddr_out),
    .ms_riscv32_mp_dmwr_mask_out(ms_riscv32_mp_dmwr_mask_out),
    .ms_riscv32_mp_dmwr_req_out(ms_riscv32_mp_dmwr_req_out),
    .ahb_htrans_out(ahb_htrans_out)

);

initial begin

    mem_wr_req_in = 1'b1;
    ahb_ready_in  = 1'b1;

    //--------------------------------
    // Store Byte
    //--------------------------------

    funct3_in = 3'b000;
    iadder_in = 32'h00000000;
    rs2_in    = 32'h000000AA;

    #10;

    funct3_in = 3'b000;
    iadder_in = 32'h00000001;
    rs2_in    = 32'h000000BB;

    #10;

    //--------------------------------
    // Store Halfword
    //--------------------------------

    funct3_in = 3'b001;
    iadder_in = 32'h00000002;
    rs2_in    = 32'h00001234;

    #10;

    //--------------------------------
    // Store Word
    //--------------------------------

    funct3_in = 3'b010;
    iadder_in = 32'h00000004;
    rs2_in    = 32'hDEADBEEF;

    #10;

    //--------------------------------
    // AHB Not Ready
    //--------------------------------

    ahb_ready_in = 0;

    #10;

    $finish;

end

initial begin

    $monitor(
    "T=%0t funct3=%b addr=%h data=%h mask=%b req=%b htrans=%b",
    $time,
    funct3_in,
    ms_riscv32_mp_dmaddr_out,
    ms_riscv32_mp_dmdata_out,
    ms_riscv32_mp_dmwr_mask_out,
    ms_riscv32_mp_dmwr_req_out,
    ahb_htrans_out
    );

end

endmodule
