module msrv32_store_unit(

    input  wire [2:0]  funct3_in,
    input  wire [31:0] iadder_in,
    input  wire [31:0] rs2_in,
    input  wire        mem_wr_req_in,
    input  wire        ahb_ready_in,

    output reg  [31:0] ms_riscv32_mp_dmdata_out,
    output wire [31:0] ms_riscv32_mp_dmaddr_out,
    output reg  [3:0]  ms_riscv32_mp_dmwr_mask_out,
    output wire        ms_riscv32_mp_dmwr_req_out,
    output reg  [1:0]  ahb_htrans_out
);

assign ms_riscv32_mp_dmaddr_out =
        {iadder_in[31:2],2'b00};

assign ms_riscv32_mp_dmwr_req_out =
        mem_wr_req_in;

always @(*) begin

    ms_riscv32_mp_dmdata_out   = 32'b0;
    ms_riscv32_mp_dmwr_mask_out = 4'b0000;

    case(funct3_in)

        // SB
        3'b000:
        begin
            case(iadder_in[1:0])

                2'b00:
                begin
                    ms_riscv32_mp_dmdata_out   = {24'b0,rs2_in[7:0]};
                    ms_riscv32_mp_dmwr_mask_out = 4'b0001;
                end

                2'b01:
                begin
                    ms_riscv32_mp_dmdata_out   = {16'b0,rs2_in[7:0],8'b0};
                    ms_riscv32_mp_dmwr_mask_out = 4'b0010;
                end

                2'b10:
                begin
                    ms_riscv32_mp_dmdata_out   = {8'b0,rs2_in[7:0],16'b0};
                    ms_riscv32_mp_dmwr_mask_out = 4'b0100;
                end

                2'b11:
                begin
                    ms_riscv32_mp_dmdata_out   = {rs2_in[7:0],24'b0};
                    ms_riscv32_mp_dmwr_mask_out = 4'b1000;
                end
            endcase
        end

        // SH
        3'b001:
        begin

            if(iadder_in[1] == 1'b0)
            begin
                ms_riscv32_mp_dmdata_out   = {16'b0,rs2_in[15:0]};
                ms_riscv32_mp_dmwr_mask_out = 4'b0011;
            end
            else
            begin
                ms_riscv32_mp_dmdata_out   = {rs2_in[15:0],16'b0};
                ms_riscv32_mp_dmwr_mask_out = 4'b1100;
            end

        end

        // SW
        3'b010:
        begin
            ms_riscv32_mp_dmdata_out   = rs2_in;
            ms_riscv32_mp_dmwr_mask_out = 4'b1111;
        end

        default:
        begin
            ms_riscv32_mp_dmdata_out   = 32'b0;
            ms_riscv32_mp_dmwr_mask_out = 4'b0000;
        end

    endcase

end

always @(*) begin

    if(mem_wr_req_in && ahb_ready_in)
        ahb_htrans_out = 2'b10;
    else
        ahb_htrans_out = 2'b00;

end

endmodule
